<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\UjiEmisi;
use App\Models\Kendaraan;
use Illuminate\Http\Request;
use Codedge\Fpdf\Fpdf\Fpdf;

// use Illuminate\Support\Facades\Session;
use Illuminate\Support\HtmlString;


class KendaraanUjiEmisiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Kendaraan $kendaraan, UjiEmisi $ujiemisi)
    {
        // dd($ujiemisi);
        // dd($kendaraan);
        return view('dashboard/ujiemisi/insert-uji', [
            "bengkel_name" => auth()->user()->bengkel_name,
            "kendaraan" => $kendaraan,
            "ujiemisi" => $ujiemisi,
        ]); 
    }


    public function showCreateFormWithKendaraan($kendaraan_id)
    {

        $kendaraan = Kendaraan::findOrFail($kendaraan_id);
        // dd($kendaraan);
        
        return view('dashboard.ujiemisi.insert-uji', [
            "bengkel_name" => auth()->user()->bengkel_name,
            'kendaraan' => $kendaraan
        ]);
    }

    public function showInputSertifikat($ujiemisi_id)
    {
        // $ujiemisi = 
        $ujiemisiLulus = UjiEmisi::findOrFail($ujiemisi_id);
        // dd($ujiemisiLulus);
        $tanggal = Carbon::parse($ujiemisiLulus->tanggal_uji)->locale('id')->translatedFormat('l, d F Y');


        return view('dashboard.ujiemisi.input-sertif', [
            "bengkel_name" => auth()->user()->bengkel_name,
            "ujiemisi" => $ujiemisiLulus,
            "tanggal_uji" => $tanggal,
        ]);
    }
    
    public function inputSertifikat(Request $request, $ujiemisi_id)
    {
        // $ujiemisi = UjiEmisi::findOrFail($ujiemisi_id);
        $ujiemisi = UjiEmisi::findOrFail($ujiemisi_id);
        $validatedData = $request->validate([
            'no_sertifikat' => 'required',
        ]);

        $ujiemisi->update($validatedData);

        // dd($ujiemisi);
        // dd($request);

        // Cetak PDF
        // $pdfContent = $this->cetakPdf($ujiemisi);

        // dd($pdfContent);
        // // Kembalikan respons HTTP dengan konten PDF
        // return response($pdfContent)
        //     ->header('Content-Type', 'application/pdf');

        $message = new HtmlString("Kendaraan dengan nomor polisi {$ujiemisi->kendaraan->nopol} dinyatakan <strong>lulus</strong> uji emisi");
        // return redirect('/dashboard/ujiemisi')->with('success', $message);
        return redirect('/dashboard/ujiemisi')->with('success', $message)->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nopol' => 'required', 
            'merk' => 'required',
            'tipe' => 'required',
            'tahun' => 'required|gt:1900',
            'cc' => 'required|gt:100',
            'no_rangka' => '',
            'no_mesin' => '',
            'kendaraan_kategori' => 'required',
            'bahan_bakar' => 'required',
            'odometer' => 'required', // tambahkan validasi uji emisi juga di sini
            'co' => 'required',
            'hc' => 'required',
            'opasitas' => '',
            'co2' => '',
            'co_koreksi' => '',
            'o2' => '',
            'putaran' => '',
            'temperatur' => '',
            'lambda' => '',
        ]);

        $kendaraan = Kendaraan::where('nopol', $validatedData['nopol'])->first();

        // Jika kendaraan belum ada, buat baru
        if (!$kendaraan) {
            $validatedData['user_id'] = auth()->user()->id;
            $kendaraan = Kendaraan::create($validatedData);
        }

        // Tambahkan data uji emisi dengan kendaraan yang ada (baik yang sudah ada atau baru dibuat)
        $ujiEmisiData = $validatedData;
        $ujiEmisiData['user_id'] = auth()->user()->id;
        $ujiEmisiData['kendaraan_id'] = $kendaraan->id;
        $ujiemisi = UjiEmisi::create($ujiEmisiData);
        
        if ($this->checkIsLulus($ujiemisi)) {
            return redirect("/dashboard/ujiemisi/input-sertif/{$ujiemisi->id}/input-nomor")->with('success', "Kendaraan dinyatakan lulus uji emisi");
        } else {
            return redirect("/dashboard/ujiemisi")->with('error', 'Kendaraan dan Uji emisi berhasil ditambah tetapi kendaraan tidak lulus uji emisi');
        }

        // return redirect("/dashboard/ujiemisi/input-sertif/{$ujiemisi->id}/input-nomor")->with('success', 'Kendaraan dinyatakan lulus uji emisi');
        // return redirect("/dashboard/ujiemisi/input-sertif/{$ujiemisi->id}/input-nomor")->with('success', 'Uji Emisi berhasil ditambahkan, dan kendaraan lulus uji emisi');

        // dd($tanggal_uji);
        // return view("/dashboard/ujiemisi/input-sertif", [
        //     'ujiemisi' => $ujiemisi,
        //     'kendaraan' => $kendaraan,
        //     "tanggal_uji" => $tanggal,
        // ]);
        


        // return redirect("/dashboard/ujiemisi/input-sertif/{$ujiemisi->id}")->with('success', 'Kendaraan memenuhi standard dan dinyatakan lulus uji emisi');
        // return redirect('/dashboard/ujiemisi')->with('success', 'Kendaraan dan hasil uji emisi berhasil ditambahkan');
        // return redirect("/dashboard/ujiemisi/input-sertif/{$ujiemisi->id}")->with('success', 'Kendaraan memenuhi standard dan dinyatakan lulus uji emisi');

    }
    

    /**
     * Display the specified resource.
     */
    public function show(Kendaraan $kendaraan, UjiEmisi $ujiemisi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Kendaraan $kendaraan, UjiEmisi $ujiemisi)
    {
        // dd($ujiemisi);
        // return view('/dashboard/ujiemisi/edit-uji', [
        //     "bengkel_name" => auth()->user()->bengkel_name,
        //     'kendaraan' => $kendaraan,
        //     'ujiemisi' => $ujiemisi,
        // ]); 
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Kendaraan $kendaraan, UjiEmisi $ujiemisi)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Kendaraan $kendaraan, UjiEmisi $ujiemisi)
    {
        //
    }

    private function checkIsLulus($ujiemisi) {
        $isLulus = false;
        // ini baru untuk bensin 
        if ($ujiemisi->kendaraan->bahan_bakar == "Bensin") {
            switch ($ujiemisi->kendaraan->kendaraan_kategori) {
              case '1':
                  if ($ujiemisi->kendaraan->tahun < 2007) {
                      if ($ujiemisi->co <= 4 && $ujiemisi->hc <=1000) {
                          $isLulus = true;
                      }
                  } elseif ($ujiemisi->kendaraan->tahun > 2018) {
                      if ($ujiemisi->co <= 0.5 && $ujiemisi->hc <= 100) {
                          $isLulus = true;
                      }
                  } else {
                      if ($ujiemisi->co <= 1 && $ujiemisi->hc <= 150) {
                          $isLulus = true;
                      }
                  }
                  break;
              
              case '2':
                  if ($ujiemisi->kendaraan->tahun < 2007) {
                      if ($ujiemisi->co <= 4 && $ujiemisi->hc <=1100) {
                          $isLulus = true;
                      }
                  } elseif ($ujiemisi->kendaraan->tahun > 2018) {
                      if ($ujiemisi->co <= 0.5 && $ujiemisi->hc <= 150) {
                          $isLulus = true;
                      }
                  } else {
                      if ($ujiemisi->co <= 1 && $ujiemisi->hc <= 200) {
                          $isLulus = true;
                      }
                  }
                  break;
              
              case '3':
                  if ($ujiemisi->kendaraan->tahun < 2007) {
                      if ($ujiemisi->co <= 4 && $ujiemisi->hc <=1100) {
                          $isLulus = true;
                      }
                  } elseif ($ujiemisi->kendaraan->tahun > 2018) {
                      if ($ujiemisi->co <= 0.5 && $ujiemisi->hc <= 150) {
                          $isLulus = true;
                      }
                  } else {
                      if ($ujiemisi->co <= 1 && $ujiemisi->hc <= 200) {
                          $isLulus = true;
                      }
                  }
                  break;
              
              case '4': // 2 tak
                  if ($ujiemisi->kendaraan->tahun < 2010) {
                      if ($ujiemisi->co <= 4.5 && $ujiemisi->hc <=6000) {
                          $isLulus = true;
                      }
                  } elseif ($ujiemisi->kendaraan->tahun > 2016) {
                      if ($ujiemisi->co <= 3 && $ujiemisi->hc <= 1000) {
                          $isLulus = true;
                      }
                  } else {
                      if ($ujiemisi->co <= 4 && $ujiemisi->hc <= 1800) {
                          $isLulus = true;
                      }
                  }
                  break;

              case '5': // 4 tak
                  if ($ujiemisi->kendaraan->tahun < 2010) {
                      if ($ujiemisi->co <= 5.5 && $ujiemisi->hc <=2200) {
                          $isLulus = true;
                      }
                  } elseif ($ujiemisi->kendaraan->tahun > 2016) {
                      if ($ujiemisi->co <= 3 && $ujiemisi->hc <= 1000) {
                          $isLulus = true;
                      }
                  } else {
                      if ($ujiemisi->co <= 4 && $ujiemisi->hc <= 1800) {
                          $isLulus = true;
                      }
                  }
                  break;
              
              default:
                  break;
          }
            # code...
        } elseif ($ujiemisi->kendaraan->bahan_bakar == "Solar") {
            if ($ujiemisi->kendaraan->tahun < 2010) {
                if ($ujiemisi->opasitas <= 65) {
                    $isLulus = true;
                }
            } elseif ($ujiemisi->kendaraan->tahun > 2021) {
                if ($ujiemisi->opasitas <= 30) {
                    $isLulus = true;
                }
            } else {
                if ($ujiemisi->opasitas <= 40) {
                    $isLulus = true;
                }
            }
        }
        return $isLulus;
    }

    private function cetakPdf($ujiemisi) {
        ob_start(); // Mulai penangkapan output
        $pdf = new FPDF('L','mm',array(250,103));
        $pdf->AddPage();
        $pdf->SetFont('courier','B',13);
        $pdf->Text(45,15,date("d-m-Y"));$pdf->Text(125,20,"test");
        $pdf->Text(45,31,strtoupper($ujiemisi->odometer));$pdf->Text(196,43,"test");//tambah 7 
        $pdf->Text(45,38,strtoupper("test"));$pdf->Text(196,50,"test");//tambah 7 **tambah6
        $pdf->Text(45,44,strtoupper("test"));$pdf->Text(196,63,"test");//tambah 6 **tambah 12
        $pdf->Text(45,51,strtoupper("test"));
        $pdf->Text(45,57,strtoupper("test"));
        $pdf->Text(45,64,strtoupper("test"));
        $pdf->Text(45,70,strtoupper("test"));
        $pdf->Text(45,76,strtoupper("test"));
        $pdf->Text(45,83,strtoupper("test"));
        $pdf->Text(45,89,strtoupper("test"));
        $pdf->Text(45,95,strtoupper("test"));$pdf->Text(168,97,strtoupper("test"));
        $pdf->Text(45,101,strtoupper(date("d-m-Y",14/07/2003)));
        $pdf->Output('S'); // Output PDF ke buffer
        $content = ob_get_contents(); // Simpan output ke dalam variabel
        ob_end_clean(); // Bersihkan output buffer
        return $content; // Kembalikan konten PDF
    }
}
